package com.best.hello.util;

public class MemInj17 {
    public void s(){

    }
}
