package com.best.hello.newPayload.RCE.MemShell;

import org.apache.xpath.operations.Bool;
import org.junit.Test;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.*;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileChannel.MapMode;
import java.util.Base64;

public class MemShell {
    public static  void main(String[] args) throws IOException {
        // FileInputStream fin = new FileInputStream("D:\\00Code_JAVA\\LeetCode\\practice\\src\\main\\java\\com\\Crucis\\Vuldemo\\com.best.hello.FilterMemShell.java");
        // String filename = "D:\\00Code_JAVA\\LeetCode\\practice\\src\\main\\java\\com\\Crucis\\Vuldemo\\com.best.hello.FilterMemShell.txt";
//        String filename = "D:\\Code_Vul\\Java-Sec-Range\\target\\classes\\FilterMemShell.class";
        String filename = "D:\\Code_Vul\\Java-Sec-Range\\target\\classes\\FilterBasedBasic.class";
        byte[] MemShell = toByteArray3(filename);
        String newfilename = "Base64FilterBasic.txt";
//        System.out.println(Base64.getEncoder().encode(MemShell));
        writeFile1(newfilename, MemShell);
        //byte[] MemShell =
    }

    public static byte[] toByteArray3(String filename) throws IOException {


        File f = new File(filename);
        if (!f.exists()) {
            throw new FileNotFoundException(filename);
        }

        ByteArrayOutputStream bos = new ByteArrayOutputStream((int) f.length());
        BufferedInputStream in = null;
        try {
            in = new BufferedInputStream(new FileInputStream(f));
            int buf_size = 1024;
            byte[] buffer = new byte[buf_size];
            int len = 0;
            while (-1 != (len = in.read(buffer, 0, buf_size))) {
                bos.write(buffer, 0, len);
            }
            return bos.toByteArray();
        } catch (IOException e) {
            e.printStackTrace();
            throw e;
        } finally {
            try {
                in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            bos.close();
        }
    }

    public static void writeFile1(String fileName, byte[] data) throws IOException {
        Boolean append = false;
        try(OutputStream out = new BufferedOutputStream(new FileOutputStream(fileName, append))){
            out.write(data);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void writeFile2(String fileName, byte[] data) throws IOException {
        try{
            Files.write(Paths.get(fileName), data);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
